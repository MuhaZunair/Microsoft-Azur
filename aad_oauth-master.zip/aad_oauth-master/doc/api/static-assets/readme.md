# highlight.js

Generated from https://highlightjs.org/download/ on 2017-08-30

Included languages:

* bash
* css
* dart
* java
* javascript
* json
* markdown
* objectivec
* ruby - dragged in by `yaml` - 🙄
* shell
* swift
* xml - includes html
* yaml
