package com.example.example_b2c

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
