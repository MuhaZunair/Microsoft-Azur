package com.example.example_oauth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
